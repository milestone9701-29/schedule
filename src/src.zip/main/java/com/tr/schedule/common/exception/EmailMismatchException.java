package com.tr.schedule.common.exception;

public class EmailMismatchException extends BusinessException {
    public EmailMismatchException(ErrorCode errorCode) { super(errorCode); }
}
