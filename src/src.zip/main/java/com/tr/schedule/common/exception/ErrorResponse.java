package com.tr.schedule.common.exception;

public record ErrorResponse(String code, String message, String path) {
}
