package com.tr.schedule.domain;


public enum Role {
    USER, // 일반 사용자
    MANAGER, // 중간 관리
    ADMIN // 시스템 전체 관리.
}
